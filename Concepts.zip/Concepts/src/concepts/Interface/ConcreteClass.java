package concepts.Interface;

public class ConcreteClass implements ConcreteInterface {

	@Override
	public void abstractHello() {
		// TODO Auto-generated method stub
		System.out.println("hello hanuman, printed through abstract method!");
	}

}
